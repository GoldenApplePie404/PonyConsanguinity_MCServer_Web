<?php
if (!defined('ACCESS_ALLOWED')) {
    header('HTTP/1.1 403 Forbidden');
    exit;
}

return array (
  'challenges' => 
  array (
    'dd35389dfe73b620f1a9910f1975a699' => 
    array (
      'target_pct' => 52.3,
      'created_at' => 1787273449,
      'used' => false,
    ),
    'bbe66021ca7fc9ddb459644a67803b15' => 
    array (
      'target_pct' => 64.7,
      'created_at' => 1787273449,
      'used' => false,
    ),
    '5623e55f5e48b6b18075fe9f2c3be244' => 
    array (
      'target_pct' => 69.0,
      'created_at' => 1787273449,
      'used' => false,
    ),
    'a140d87260d475ac7d9715f7c0aa7abd' => 
    array (
      'target_pct' => 37.0,
      'created_at' => 1787273461,
      'used' => true,
    ),
  ),
  'tokens' => 
  array (
    '634ef49bfd36c3abac4deb3665de5d35170cb08975bff1e3' => 
    array (
      'created_at' => 1787273401,
      'used' => false,
    ),
    '678db56009dfec50f816564718150223f851ee2132e789af' => 
    array (
      'created_at' => 1787273412,
      'used' => false,
    ),
    'ccf3fdf6aa7779d884283a41528d00db030ca8b804f2c60e' => 
    array (
      'created_at' => 1787273427,
      'used' => false,
    ),
    '820cf5fba078fd5dff5abab0e399a539ec8e3ef9cee614e2' => 
    array (
      'created_at' => 1787273478,
      'used' => false,
    ),
  ),
);
?>