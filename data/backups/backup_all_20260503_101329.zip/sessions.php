<?php
if (!defined('ACCESS_ALLOWED')) {
    header('HTTP/1.1 403 Forbidden');
    exit;
}

return array (
  '94d77846-c4cc-4058-bddf-4943d39ee656' => 
  array (
    'user_id' => '990606f8-ccf1-44ba-8cfc-873401672d65',
    'username' => '金苹果派',
    'role' => 'admin',
    'created_at' => '2026-03-17 10:54:50',
  ),
  'e61f207e-8d04-4564-b658-9d347a79b885' => 
  array (
    'user_id' => '990606f8-ccf1-44ba-8cfc-873401672d65',
    'username' => '金苹果派',
    'role' => 'admin',
    'created_at' => '2026-03-19 16:05:12',
  ),
  '8826b875-4d96-4e4c-b37a-9660896d42f3' => 
  array (
    'user_id' => '990606f8-ccf1-44ba-8cfc-873401672d65',
    'username' => '金苹果派',
    'role' => 'admin',
    'created_at' => '2026-03-20 16:10:32',
  ),
  '091234a9-0165-4ea7-8408-48c99f52201a' => 
  array (
    'user_id' => '990606f8-ccf1-44ba-8cfc-873401672d65',
    'username' => '金苹果派',
    'role' => 'admin',
    'created_at' => '2026-03-22 03:15:58',
  ),
  '1da15c8d-3663-46ad-b893-dc01b567186e' => 
  array (
    'user_id' => '990606f8-ccf1-44ba-8cfc-873401672d65',
    'username' => '金苹果派',
    'role' => 'admin',
    'created_at' => '2026-04-03 11:20:05',
  ),
  'e76c5fc3-db80-4073-89f0-aeb1e61678cc' => 
  array (
    'user_id' => '990606f8-ccf1-44ba-8cfc-873401672d65',
    'username' => '金苹果派',
    'role' => 'admin',
    'created_at' => '2026-04-08 16:10:08',
  ),
  'd9fa716d-da16-4d7f-baf0-012b6d660bed' => 
  array (
    'user_id' => 'ed2f1a94-0b92-4f86-83f8-29cdbaf65671',
    'username' => 'GoldenApplePie',
    'role' => 'admin',
    'created_at' => '2026-05-03 05:26:05',
  ),
  '2f3e60f3-3a1e-42ea-86c8-6c6b1f0beb82' => 
  array (
    'user_id' => 'ed2f1a94-0b92-4f86-83f8-29cdbaf65671',
    'username' => 'GoldenApplePie',
    'role' => 'admin',
    'created_at' => '2026-05-03 07:03:37',
  ),
  'a0f73aab-5cd7-4bf2-a048-9c6c46712467' => 
  array (
    'user_id' => 'ed2f1a94-0b92-4f86-83f8-29cdbaf65671',
    'username' => 'GoldenApplePie',
    'role' => 'admin',
    'created_at' => '2026-05-03 09:02:50',
  ),
  '0432d7b4-4e48-48f4-a91e-44aae8a68236' => 
  array (
    'user_id' => 'ed2f1a94-0b92-4f86-83f8-29cdbaf65671',
    'username' => 'GoldenApplePie',
    'role' => 'admin',
    'created_at' => '2026-05-03 09:12:10',
  ),
);
?>